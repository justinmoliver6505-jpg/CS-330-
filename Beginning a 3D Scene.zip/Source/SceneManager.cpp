///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (image)
    {
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
            return false;

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    return false;
}

/***********************************************************
 *  BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glGenTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
        if (m_textureIDs[i].tag.compare(tag) == 0)
            return m_textureIDs[i].ID;

    return -1;
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
        if (m_textureIDs[i].tag.compare(tag) == 0)
            return i;

    return -1;
}

/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
        return false;

    for (int i = 0; i < m_objectMaterials.size(); i++)
    {
        if (m_objectMaterials[i].tag.compare(tag) == 0)
        {
            material = m_objectMaterials[i];
            return true;
        }
    }

    return false;
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1, 0, 0));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0, 1, 0));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0, 0, 1));
    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    glm::vec4 currentColor(r, g, b, a);

    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        int slot = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager)
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    OBJECT_MATERIAL material;
    if (FindMaterial(materialTag, material))
    {
        m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);
    }
}

/***********************************************************
 *  PrepareScene()
 *  additions are necessary here to render the new objects
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Load all meshes you plan to draw
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
}

/***********************************************************
 *  DrawLightPole()
 *  creates the 3D image of the lightpole from my scene.
 *  this creates four pieces that come together to make one image.
 ***********************************************************/
void SceneManager::DrawLightPole()
{
    glm::vec3 scaleXYZ;
    float Xrot = 0.0f;
    float Yrot = 0.0f;
    float Zrot = 0.0f;
    glm::vec3 posXYZ;

    // Pole (cylinder)
    scaleXYZ = glm::vec3(0.2f, 4.0f, 0.2f);
    posXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, posXYZ);
    SetShaderColor(0.6f, 0.6f, 0.6f, 1.0f);  // metal color
    m_basicMeshes->DrawCylinderMesh();

    // Lamp head (box)
    scaleXYZ = glm::vec3(0.6f, 0.4f, 0.6f);
    posXYZ = glm::vec3(0.0f, 4.2f, 0.0f);

    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, posXYZ);
    SetShaderColor(1.0f, 1.0f, 0.8f, 1.0f);     // ambient glow (yellowish)
    m_basicMeshes->DrawBoxMesh();

    // Draw the top cover (tapered cylinder)
    scaleXYZ = glm::vec3(0.7f, 0.3f, 0.7f);   // wider + short
    posXYZ = glm::vec3(0.0f, 4.6f, 0.0f);    // slightly above lamp head

    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, posXYZ);
    SetShaderColor(0.6f, 0.6f, 0.6f, 1.0f);    // metal color
    m_basicMeshes->DrawTaperedCylinderMesh();

    
    // Draw the base plate (box)
    scaleXYZ = glm::vec3(1.0f, 0.2f, 1.0f);   // wide + flat
    posXYZ = glm::vec3(0.0f, -0.1f, 0.0f);  // slightly below pole bottom

    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, posXYZ);
    SetShaderColor(0.4f, 0.4f, 0.4f, 1.0f);   // darker metal color
    m_basicMeshes->DrawBoxMesh();

}

/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    float Xrot = 0.0f;
    float Yrot = 0.0f;
    float Zrot = 0.0f;
    glm::vec3 posXYZ;

    // Ground plane
    scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
    posXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

    SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, posXYZ);
    SetShaderColor(1, 1, 1, 1);
    m_basicMeshes->DrawPlaneMesh();

    // Light pole
    DrawLightPole();
}
